package sLivros;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextPane;
import java.awt.TextArea;

public class Autor extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtnome;
	private JTable jTable1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Autor frame = new Autor();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	
	
	
	
	
	/**
	 * Create the frame.
	 */
	public Autor() {
		
		//Conexao DB
		Conectar();
		SwingUtilities.invokeLater(() -> carregarAutor());
		
		
		//===========================
		
												
								
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 820, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(10, 13, 788, 437);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Autor");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel.setBounds(145, 13, 90, 40);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Nome do Autor");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(10, 88, 130, 16);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Endereco");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(10, 175, 71, 16);
		panel.add(lblNewLabel_1_1);
		
		txtnome = new JTextField();
		txtnome.setBounds(112, 86, 150, 22);
		panel.add(txtnome);
		txtnome.setColumns(10);
		
		JButton btnNewButton = new JButton("Adicionar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String nome = txtnome.getText();
				String endereco = txtendereco.getText(); //Solucao de erro, converter variavel de local para de campo
				String fone = txtfone.getText();
				
				String titl = "Sucesso!";
				String cat = "Autor criado!!";
				
				try {
					pst = con.prepareStatement("insert into autor(nome, endereco, telefone) values(?,?,?)");
					pst.setString(1, nome);
					pst.setString(2, endereco);
					pst.setString(3, fone);
					
					int k = pst.executeUpdate();
					
					if(k == 1) {
						JOptionPane.showMessageDialog(null, this, cat, k);
						
						txtnome.setText("");
						txtendereco.setText("");
						txtfone.setText("");
						txtnome.requestFocus();
						carregarAutor();
						
						
					}else {
						JOptionPane.showMessageDialog(null, this, "Erro!!", k);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton.setBounds(59, 313, 90, 40);
		panel.add(btnNewButton);
		
		JButton btnAtualizar = new JButton("Atualizar");
		btnAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DefaultTableModel d1 = (DefaultTableModel) jTable1.getModel();
				int selectIndex = jTable1.getSelectedRow();
				
				//Trocando valores de index de 1 para 0
				int id = Integer.parseInt(d1.getValueAt(selectIndex, 0).toString());
				
				
				
				
				
				
				String nome = txtnome.getText();
				String endereco = txtendereco.getText(); //Solucao de erro, converter variavel de local para de campo
				String fone = txtfone.getText();
				
				String titl = "Sucesso!";
				String cat = "Autor atualizado!!";
				
				try {
					pst = con.prepareStatement("update autor set nome = ?, endereco = ?, telefone = ? where id = ?"); //Erro no nome (name?)
					pst.setString(1, nome);
					pst.setString(2, endereco);
					pst.setString(3, fone);
					pst.setInt(4, id);
					
					
					int k = pst.executeUpdate();
					
					if(k == 1) {
						JOptionPane.showMessageDialog(null, this, cat, k);
						
						txtnome.setText("");
						txtendereco.setText("");
						txtfone.setText("");
						txtnome.requestFocus();
						//carregarAutor();
						btnAtualizar.setEnabled(true);
						
						
					}else {
						JOptionPane.showMessageDialog(null, this, "Erro!!", k);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
				
			}
		});
		btnAtualizar.setBounds(161, 313, 90, 40);
		panel.add(btnAtualizar);
		
		JButton btnNewButton_1 = new JButton("Deletar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DefaultTableModel d1 = (DefaultTableModel) jTable1.getModel();
				int selectIndex = jTable1.getSelectedRow();
				
				//Trocando valores de index de 1 para 0
				int id = Integer.parseInt(d1.getValueAt(selectIndex, 0).toString());
				
				
				String titl = "Sucesso!";
				String cat = "Autor deletado!!";
				
				try {
					pst = con.prepareStatement("delete from autor where id = ?");
					pst.setInt(1, id);
					
					
					int k = pst.executeUpdate();
					
					if(k == 1) {
						JOptionPane.showMessageDialog(null, this, cat, k);
						
						txtnome.setText("");
						txtendereco.setText("");
						txtfone.setText("");
						txtnome.requestFocus();
						carregarAutor();
						btnAtualizar.setEnabled(true);
						
					}else {
						JOptionPane.showMessageDialog(null, this, "Erro!!", k);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
				
			}
		});
		btnNewButton_1.setBounds(59, 370, 90, 40);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Cancelar"); //Action aqui!!
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//alternativa provisoria
				 setVisible(false); 
				 
				 /*
				  * Por que essa alternativa funcionou? Nao sei. setVisible(false) excluiu a janela
				  * sem parar o programa.
				  */
				  
				

			}
		});
		btnNewButton_2.setBounds(161, 370, 90, 40);
		panel.add(btnNewButton_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				DefaultTableModel d1 = (DefaultTableModel) jTable1.getModel();
				int selectIndex = jTable1.getSelectedRow();
				
				//Trocando valores de index de 1 para 0
				int id = Integer.parseInt(d1.getValueAt(selectIndex, 0).toString());
				
				txtnome.setText(d1.getValueAt(selectIndex, 1).toString());
				txtendereco.setText(d1.getValueAt(selectIndex, 2).toString());
				txtfone.setText(d1.getValueAt(selectIndex, 3).toString());
				
				btnNewButton.setEnabled(false);
				
			}
		});
		scrollPane.setBounds(363, 13, 413, 351);
		panel.add(scrollPane);
		
		
		//DefaultTableModel tableModel = new DefaultTableModel(0,0); //Recem adicionado
		jTable1 = new JTable();
		scrollPane.setViewportView(jTable1);
		jTable1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Nome Autor", "Endereco", "Telefone"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, String.class, Integer.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		jTable1.getColumnModel().getColumn(1).setPreferredWidth(112);
		jTable1.setShowVerticalLines(true);
		jTable1.setShowHorizontalLines(true);
		
		txtendereco = new TextArea();
		txtendereco.setBounds(87, 175, 270, 110);
		panel.add(txtendereco);
		
		JLabel lblNewLabel_2 = new JLabel("Telefone");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_2.setBounds(10, 136, 55, 14);
		panel.add(lblNewLabel_2);
		
		txtfone = new JTextField();
		txtfone.setBounds(112, 131, 150, 20);
		panel.add(txtfone);
		txtfone.setColumns(10);
		
		

		
		
		//carregarCategoria();
		

	}
	
	
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	private JTextField txtfone;
	private TextArea txtendereco;
	
	public void Conectar() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/slivro", "root", "M@7h3u$");
		} catch (ClassNotFoundException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} catch(SQLException ex) {
			
		}
	}
	
	
	public void carregarAutor() {
		int c;
		try {
			pst = con.prepareStatement("select * from autor");
			rs = pst.executeQuery();
			
			ResultSetMetaData rsd = rs.getMetaData();
			c = rsd.getColumnCount();
			
			
			
			
			/*DefaultTableModel d = (DefaultTableModel)jTable1.getModel();
			d.setRowCount(0);*/
			
			DefaultTableModel d = (DefaultTableModel) jTable1.getModel();
			d.setRowCount(0); // Limpa as linhas existentes
			jTable1.setModel(d); // Garante que o modelo está corretamente atribuído

			
			
			while(rs.next()) {
				Vector v2 = new Vector();
				
				for(int i = 1; i <= c; i++) {
					v2.add(rs.getString("id"));
					v2.add(rs.getString("nome"));
					v2.add(rs.getString("endereco"));
					v2.add(rs.getString("telefone"));
					
				}
				
				d.addRow(v2);
			}
		}catch(SQLException ex) {
			
		}
		
		
	}
}
