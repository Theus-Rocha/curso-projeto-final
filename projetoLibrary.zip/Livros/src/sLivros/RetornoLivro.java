package sLivros;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Vector;

import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextPane;
import java.awt.TextArea;
import javax.swing.JSpinner;
import javax.swing.JList;
import javax.swing.SpinnerDateModel;
import java.util.Date;
import java.util.Calendar;
import com.toedter.calendar.JDayChooser;

import sLivros.Livro.CategoriaItem;

import com.toedter.calendar.JDateChooser;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;



public class RetornoLivro extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtmid;
	private JTable jTable1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RetornoLivro frame = new RetornoLivro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	
	
	
	
	
	/**
	 * Create the frame.
	 */
	public RetornoLivro() {
		
		
		
		
		
		
		
		
		
		
		SwingUtilities.invokeLater(() ->  carregarRetornoLivro());
		//Conexao DB
		Conectar();
		 
		
		//===========================
		
		
												
								
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 490);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(10, 13, 864, 427);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Retorno Livro");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel.setBounds(55, 13, 194, 40);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ID Membro");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(10, 88, 81, 16);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Nome Membro");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(10, 137, 90, 16);
		panel.add(lblNewLabel_1_1);
		
		txtmid = new JTextField();
		txtmid.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				if(e.getKeyCode() == KeyEvent.VK_ENTER);
				
				String id = txtmid.getText();
				String msg = "Id membro não encontrado!!";
				
				
				try {
					pst = con.prepareStatement("select m.nome, l.lnome, e.retornodata, DATEDIFF(now(), e.retornodata) as passado from emprestalivro e join membro m on e.membroid = m.id join livro l on e.livroid = l.id and e.membroid = ?");
					pst.setString(1, id);
					rs = pst.executeQuery();
					
					if(rs.next() == false) {
						JOptionPane.showMessageDialog(null, msg);
					}else {
						String mnome = rs.getString("m.nome");
						String lnome = rs.getString("m.lnome");
						
						
						txtmnome.setText(mnome.trim()) ;
						txtlivro_1.setText(lnome.trim());
						
						String date = rs.getString("e.retornodata");
						txtrdate.setText(date);
						
						String elp = rs.getString("taxa");
						
						int elaped = Integer.parseInt(elp);
						
						if(elaped > 0) {
							txtpass.setText(elp);
							int juros = elaped * 100;
							txtpass.setText(String.valueOf(juros));
						}else {
							txtpass.setText("0");
							txtpass.setText("0");
						}
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
				
				
			}
		});
		txtmid.setBounds(110, 86, 152, 22);
		panel.add(txtmid);
		txtmid.setColumns(10);
		
		JButton btnNewButton = new JButton("Adicionar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String mid = txtmid.getText();
				String membronome = txtmnome.getText();
				String livronome = txtlivro_1.getText();
				String dataretorno = txtrdate.getText();
				String elpdays = txtpass.getText();
				String taxa = txtpass.getText();
				
				
				
				String titl = "Sucesso!";
				String inf = "Livro devolvido!!";
				String info = "Ops!";
				String msg3 = "Algo errado";
				try {
					pst = con.prepareStatement("insert into devolucaolivro(mid, mnome, lnome, dataretorno, elp, taxa) values(?,?,?,?,?,?)");
					pst.setString(1, mid);
					pst.setString(2, membronome);
					pst.setString(3, livronome);
					pst.setString(4, dataretorno);
					pst.setString(5, elpdays);
					pst.setString(6, taxa);
					
					int k = pst.executeUpdate();
					
					pst = con.prepareStatement("delete from emprestalivro where membroid = ?");
					pst.setString(1, mid);
					pst.executeUpdate();
					
					
					if(k == 1) {
						JOptionPane.showMessageDialog(null, inf, titl, 2);
						
						txtmid.setText("");
						txtmnome.setText("");
						txtlivro_1.setText("");
						txtrdate.setText("");
						txtpass.setText(""); //CORRECAO
						txtmid.requestFocus();
						
						
						
					}else {
						JOptionPane.showMessageDialog(null, msg3, info, 2);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton.setBounds(10, 319, 90, 40);
		panel.add(btnNewButton);
		
		JButton btnAtualizar = new JButton("Atualizar");
		btnAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				
				
				
				
			}
		});
		btnAtualizar.setBounds(112, 319, 90, 40);
		panel.add(btnAtualizar);
		
		JButton btnNewButton_1 = new JButton("Deletar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				
				
				
			}
		});
		btnNewButton_1.setBounds(10, 376, 90, 40);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Cancelar"); //Action aqui!!
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//alternativa provisoria
				 setVisible(false); 
				 
				 /*
				  * Por que essa alternativa funcionou? Nao sei. setVisible(false) excluiu a janela
				  * sem parar o programa.
				  */
				  
				

			}
		});
		btnNewButton_2.setBounds(112, 376, 90, 40);
		panel.add(btnNewButton_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
				
				btnNewButton.setEnabled(false);
				
			}
		});
		//AQUI!!! SCR
		scrollPane.setBounds(296, 13, 558, 413);
		panel.add(scrollPane);
		
		
		//DefaultTableModel tableModel = new DefaultTableModel(0,0); //Recem adicionado
		jTable1 = new JTable();
		scrollPane.setViewportView(jTable1);
		jTable1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Membro ID", "Nome Membro", "Livro", "Data Retorno", "Dias Corridos"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, Integer.class, Object.class, Object.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		jTable1.setShowVerticalLines(true);
		jTable1.setShowHorizontalLines(true);
		
	
		JLabel lblNewLabel_1_1_1 = new JLabel("Livro");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1.setBounds(10, 184, 71, 16);
		panel.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Data Retorno");
		lblNewLabel_1_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1.setBounds(10, 224, 90, 16);
		panel.add(lblNewLabel_1_1_1_1_1);
		
		txtmnome = new JLabel("Nome");
		txtmnome.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtmnome.setBounds(110, 139, 92, 14);
		panel.add(txtmnome);
		
		txtlivro_1 = new JLabel("Nome");
		txtlivro_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtlivro_1.setBounds(110, 186, 92, 14);
		panel.add(txtlivro_1);
		
		JLabel lblNewLabel_1_1_1_1_1_1 = new JLabel("Dias Passados");
		lblNewLabel_1_1_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1_1.setBounds(10, 260, 90, 16);
		panel.add(lblNewLabel_1_1_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1_1_1 = new JLabel("Taxa");
		lblNewLabel_1_1_1_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1_1_1.setBounds(10, 292, 90, 16);
		panel.add(lblNewLabel_1_1_1_1_1_1_1);
		
		txtpass = new JTextField();
		txtpass.setBounds(110, 259, 108, 20);
		panel.add(txtpass);
		txtpass.setColumns(10);
		
		txttaxa = new JTextField();
		txttaxa.setBounds(110, 291, 108, 20);
		panel.add(txttaxa);
		txttaxa.setColumns(10);
		
		txtrdate = new JLabel("Data");
		txtrdate.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtrdate.setBounds(110, 226, 43, 14);
		panel.add(txtrdate);
		
		

		
		
		//carregarCategoria();
		

	}
	
	
	
	
	
	

	
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	private JTextField txtpass;
	private JTextField txttaxa;
	private JLabel txtmnome;
	private JLabel txtlivro_1;
	private JLabel txtrdate;
	
	
	

	public void Conectar() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/slivro", "root", "M@7h3u$");
		} catch (ClassNotFoundException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} catch(SQLException ex) {
			
		}
	}
	
	
	
	
	
	
	
	
	
	public void carregarRetornoLivro() {
		int c;
		try {
			pst = con.prepareStatement("select * from devolucaolivro"); // Tabela so mostrara registros se mudar o nome da onde esta sendo chamado
			rs = pst.executeQuery();
			
			ResultSetMetaData rsd = rs.getMetaData();
			c = rsd.getColumnCount();
			
			
			
			
			/*DefaultTableModel d = (DefaultTableModel)jTable1.getModel();
			d.setRowCount(0);*/
			
			jTable1 = new JTable();//provisorio!!!!!!!!!!
			
			DefaultTableModel d = (DefaultTableModel) jTable1.getModel();
			d.setRowCount(0); // Limpa as linhas existentes
			jTable1.setModel(d); // Garante que o modelo está corretamente atribuído

			
			
			while(rs.next()) {
				Vector v2 = new Vector();
				
				for(int i = 1; i <= c; i++) {
					v2.add(rs.getString("id"));
					v2.add(rs.getString("mid"));
					v2.add(rs.getString("lnome"));
					v2.add(rs.getString("dataretorno"));
					v2.add(rs.getString("elp"));
					v2.add(rs.getString("taxa"));
					
					
				}
				
				d.addRow(v2);
			}
		}catch(SQLException ex) {
			
		}
		
		
	}
}








