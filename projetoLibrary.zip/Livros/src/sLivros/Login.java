package sLivros;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import javax.swing.SwingConstants;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtusuario;
	private JPasswordField txtsenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 538, 422);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(10, 11, 500, 357);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Usuario");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel.setBackground(new Color(255, 255, 255));
		lblNewLabel.setBounds(92, 154, 58, 14);
		panel.add(lblNewLabel);
		
		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblSenha.setBackground(Color.WHITE);
		lblSenha.setBounds(92, 192, 46, 14);
		panel.add(lblSenha);
		
		txtusuario = new JTextField();
		txtusuario.setBounds(160, 152, 180, 20);
		panel.add(txtusuario);
		txtusuario.setColumns(10);
		
		JButton btnNewButton = new JButton("Cancelar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
				
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnNewButton.setBounds(138, 242, 89, 23);
		panel.add(btnNewButton);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String Usuario = txtusuario.getText();
				String Senha = txtsenha.getText();
				String msg = "Usuario ou senha não combinam";
				String ttl = "usuario ou senha incorretos";
				
				if(Usuario.equals("Matheus") && Senha.equals("123") || Usuario.equals("Marcus") && Senha.equals("gabigol"))
				{
					Main m = new Main();
					//this.hide();
					m.setVisible(true);									
					
				}else {
					JOptionPane.showMessageDialog(null, msg, ttl, 2);
					txtusuario.setText("");
					txtsenha.setText("");
					txtusuario.requestFocus();
									
				}
				
				//Centralizar classe Login sem fazer ou foi feito automaticamente
				
			}
		});
		
		
		btnLogin.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnLogin.setBounds(251, 242, 89, 23);
		panel.add(btnLogin);
		
		JLabel lblNewLabel_1 = new JLabel("Login");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_1.setBounds(215, 47, 70, 46);
		panel.add(lblNewLabel_1);
		
		txtsenha = new JPasswordField();
		txtsenha.setHorizontalAlignment(SwingConstants.LEFT);
		txtsenha.setBounds(160, 190, 180, 20);
		panel.add(txtsenha);
		setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{contentPane, panel, lblNewLabel, txtusuario, lblSenha, txtsenha, btnNewButton, btnLogin, lblNewLabel_1}));
	}
}
