package sLivros;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Categoria extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtcategoria;
	private JTable jTable1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Categoria frame = new Categoria();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	
	
	
	
	
	/**
	 * Create the frame.
	 */
	public Categoria() {
		
		//Conexao DB
		Conectar();
		SwingUtilities.invokeLater(() -> carregarCategoria());
		
		
		//===========================
		
												
								
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 820, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(10, 13, 788, 437);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Categoria");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel.setBounds(145, 13, 140, 40);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Nome da Categoria");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(59, 155, 130, 16);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Status");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(59, 239, 55, 16);
		panel.add(lblNewLabel_1_1);
		
		txtcategoria = new JTextField();
		txtcategoria.setBounds(201, 152, 150, 22);
		panel.add(txtcategoria);
		txtcategoria.setColumns(10);
		
		JComboBox txtstatus = new JComboBox();
		txtstatus.setModel(new DefaultComboBoxModel(new String[] {"Ativado", "Desativado"}));
		txtstatus.setBounds(201, 234, 150, 26);
		panel.add(txtstatus);
		
		JButton btnNewButton = new JButton("Adicionar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String categoria = txtcategoria.getText();
				String status = txtstatus.getSelectedItem().toString();
				String titl = "Sucesso!";
				String cat = "Categoria criada!!";
				
				try {
					pst = con.prepareStatement("insert into categoria(catnome, status) values(?,?)");
					pst.setString(1, categoria);
					pst.setString(2, status);
					int k = pst.executeUpdate();
					
					if(k == 1) {
						JOptionPane.showMessageDialog(null, this, cat, k);
						txtcategoria.setText("");
						txtstatus.setSelectedIndex(1);
						txtcategoria.requestFocus();
						carregarCategoria();
					}else {
						JOptionPane.showMessageDialog(null, this, "Erro!!", k);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton.setBounds(59, 313, 90, 40);
		panel.add(btnNewButton);
		
		JButton btnAtualizar = new JButton("Atualizar");
		btnAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DefaultTableModel d1 = (DefaultTableModel) jTable1.getModel();
				int selectIndex = jTable1.getSelectedRow();
				
				int id = Integer.parseInt(d1.getValueAt(selectIndex, 1).toString());
				
				
				
				
				String categoria = txtcategoria.getText();
				String status = txtstatus.getSelectedItem().toString();
				String titl = "Sucesso!";
				String cat = "Categoria atualizada!!";
				
				try {
					pst = con.prepareStatement("update categoria set catnome = ?, status = ? where id = ?");
					pst.setString(1, categoria);
					pst.setString(2, status);
					pst.setInt(3, id);
					
					int k = pst.executeUpdate();
					
					if(k == 1) {
						JOptionPane.showMessageDialog(null, this, cat, k);
						txtcategoria.setText("");
						txtstatus.setSelectedIndex(1);
						txtcategoria.requestFocus();
						carregarCategoria();
						btnNewButton.setEnabled(true);
						
						
					}else {
						JOptionPane.showMessageDialog(null, this, "Erro!!", k);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
				
			}
		});
		btnAtualizar.setBounds(161, 313, 90, 40);
		panel.add(btnAtualizar);
		
		JButton btnNewButton_1 = new JButton("Deletar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				DefaultTableModel d1 = (DefaultTableModel) jTable1.getModel();
				int selectIndex = jTable1.getSelectedRow();
				
				int id = Integer.parseInt(d1.getValueAt(selectIndex, 0).toString());
				
										
				 
				String titl = "Sucesso!";
				String cat = "Categoria deletada!!";
				
				try {
					pst = con.prepareStatement("delete from categoria where id = ?");					 
					pst.setInt(0, id);
					
					int k = pst.executeUpdate();
					
					if(k == 1) {
						JOptionPane.showMessageDialog(null, this, cat, k);
						txtcategoria.setText("");
						txtstatus.setSelectedIndex(1);
						txtcategoria.requestFocus();
						carregarCategoria();
						btnNewButton.setEnabled(true);
						
						
					}else {
						JOptionPane.showMessageDialog(null, this, "Erro!!", k);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
				
			}
		});
		btnNewButton_1.setBounds(59, 370, 90, 40);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Cancelar"); //Action aqui!!
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//alternativa provisoria
				 setVisible(false); 
				 
				 /*
				  * Por que essa alternativa funcionou? Nao sei. setVisible(false) excluiu a janela
				  * sem parar o programa.
				  */
				  
				

			}
		});
		btnNewButton_2.setBounds(161, 370, 90, 40);
		panel.add(btnNewButton_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				DefaultTableModel d1 = (DefaultTableModel) jTable1.getModel();
				int selectIndex = jTable1.getSelectedRow();
				
				int id = Integer.parseInt(d1.getValueAt(selectIndex, 0).toString());
				txtcategoria.setText(d1.getValueAt(selectIndex, 1).toString());
				txtstatus.setSelectedItem(d1.getValueAt(selectIndex, 2).toString());
				
				btnNewButton.setEnabled(false);
				
			}
		});
		scrollPane.setBounds(363, 13, 413, 351);
		panel.add(scrollPane);
		
		
		//DefaultTableModel tableModel = new DefaultTableModel(0,0); //Recem adicionado
		jTable1 = new JTable();
		scrollPane.setViewportView(jTable1);
		jTable1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Nome & Categoria", "Status"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		jTable1.getColumnModel().getColumn(1).setPreferredWidth(112);
		jTable1.setShowVerticalLines(true);
		jTable1.setShowHorizontalLines(true);
		
		

		
		
		//carregarCategoria();
		

	}
	
	
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	
	public void Conectar() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/slivro", "root", "M@7h3u$");
		} catch (ClassNotFoundException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} catch(SQLException ex) {
			
		}
	}
	
	
	public void carregarCategoria() {
		int c;
		try {
			pst = con.prepareStatement("select * from categoria");
			rs = pst.executeQuery();
			
			ResultSetMetaData rsd = rs.getMetaData();
			c = rsd.getColumnCount();
			
			
			
			
			/*DefaultTableModel d = (DefaultTableModel)jTable1.getModel();
			d.setRowCount(0);*/
			
			DefaultTableModel d = (DefaultTableModel) jTable1.getModel();
			d.setRowCount(0); // Limpa as linhas existentes
			jTable1.setModel(d); // Garante que o modelo está corretamente atribuído

			
			
			while(rs.next()) {
				Vector v2 = new Vector();
				
				for(int i = 1; i <= c; i++) {
					v2.add(rs.getString("id"));
					v2.add(rs.getString("catnome")); //Erro: estava escrito categoria ao inves de catnome!!!!
					v2.add(rs.getString("status"));
					
				}
				
				d.addRow(v2);
			}
		}catch(SQLException ex) {
			
		}
		
		
	}
	
	
}
