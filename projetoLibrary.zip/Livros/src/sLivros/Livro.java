package sLivros;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextPane;
import java.awt.TextArea;

public class Livro extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtnome;
	private JTable jTable1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Livro frame = new Livro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	
	
	
	
	
	/**
	 * Create the frame.
	 */
	public Livro() {
		
		
		
		
		
		
		
		
		
		
		SwingUtilities.invokeLater(() -> carregarLivro());
		//Conexao DB
		Conectar();
		Categoria();
		chamarAutor();
		chamarEditora();
		
		
		//===========================
		
		
												
								
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(10, 13, 864, 537);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Livro");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel.setBounds(145, 13, 106, 40);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Nome Livro");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(10, 88, 81, 16);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Categoria");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(10, 137, 71, 16);
		panel.add(lblNewLabel_1_1);
		
		txtnome = new JTextField();
		txtnome.setBounds(112, 86, 150, 22);
		panel.add(txtnome);
		txtnome.setColumns(10);
		
		JButton btnNewButton = new JButton("Adicionar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String lnome = txtnome.getText();
				CategoriaItem citem = (CategoriaItem)txtcategoria.getSelectedItem();
				AutorItem aitem = (AutorItem)txtautor.getSelectedItem();
				EditoraItem eitem = (EditoraItem)txteditora.getSelectedItem();
				
				String conteudos = txtconteudo.getText();
				String paginas = txtnumerop.getText();
				String edicao = txtedicao.getText();
				
				
				
				
				String titl = "Sucesso!";
				String inf = "Livro criado(a)!!";
				String info = "Ops!";
				String msg3 = "Algo errado";
				try {
					pst = con.prepareStatement("insert into livro(lnome, categoria, autor, editora, conteudos, paginas, edicao) values(?,?,?,?,?,?,?)");
					pst.setString(1, lnome);
					pst.setInt(2, citem.id);
					pst.setInt(3, aitem.id);
					pst.setInt(4, eitem.id);
					pst.setString(5, conteudos);
					pst.setString(6, paginas);
					pst.setString(7, edicao);
					
					int k = pst.executeUpdate();
					
					if(k == 1) {
						JOptionPane.showMessageDialog(null, inf, titl, 2);
						
						txtnome.setText("");
						txtcategoria.setSelectedIndex(-1);
						txtautor.setSelectedIndex(-1);
						txteditora.setSelectedIndex(-1);
						txtconteudo.setText("");
						txtnumerop.setText("");
						txtedicao.setText("");
						
						//carregarLivro();
						
						
					}else {
						JOptionPane.showMessageDialog(null, msg3, info, 2);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton.setBounds(59, 395, 90, 40);
		panel.add(btnNewButton);
		
		JButton btnAtualizar = new JButton("Atualizar");
		btnAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				
				
				
				
			}
		});
		btnAtualizar.setBounds(161, 395, 90, 40);
		panel.add(btnAtualizar);
		
		JButton btnNewButton_1 = new JButton("Deletar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				
				
				
			}
		});
		btnNewButton_1.setBounds(59, 452, 90, 40);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Cancelar"); //Action aqui!!
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//alternativa provisoria
				 setVisible(false); 
				 
				 /*
				  * Por que essa alternativa funcionou? Nao sei. setVisible(false) excluiu a janela
				  * sem parar o programa.
				  */
				  
				

			}
		});
		btnNewButton_2.setBounds(161, 452, 90, 40);
		panel.add(btnNewButton_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
				
				btnNewButton.setEnabled(false);
				
			}
		});
		//AQUI!!! SCR
		scrollPane.setBounds(296, 13, 558, 513);
		panel.add(scrollPane);
		
		
		//DefaultTableModel tableModel = new DefaultTableModel(0,0); //Recem adicionado
		jTable1 = new JTable();
		scrollPane.setViewportView(jTable1);
		jTable1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Nome Livro", "Categoria", "Autor", "Editora", "Conteudos", "n\u00B0 paginas", "Edi\u00E7\u00E3o"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, Object.class, String.class, Object.class, Integer.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		jTable1.getColumnModel().getColumn(1).setPreferredWidth(112);
		jTable1.setShowVerticalLines(true);
		jTable1.setShowHorizontalLines(true);
		
		txtcategoria = new JComboBox();
		txtcategoria.setBounds(112, 135, 150, 22);
		panel.add(txtcategoria);
		
	
		JLabel lblNewLabel_1_1_1 = new JLabel("Autor");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1.setBounds(10, 184, 71, 16);
		panel.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Editora");
		lblNewLabel_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_1.setBounds(10, 229, 71, 16);
		panel.add(lblNewLabel_1_1_1_1);
		
		txtautor = new JComboBox();
		txtautor.setBounds(112, 182, 150, 22);
		panel.add(txtautor);
		
		txteditora = new JComboBox();
		txteditora.setBounds(112, 227, 150, 22);
		panel.add(txteditora);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Conteudos");
		lblNewLabel_1_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1.setBounds(10, 272, 71, 16);
		panel.add(lblNewLabel_1_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1_1 = new JLabel("N° Paginas");
		lblNewLabel_1_1_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1_1.setBounds(10, 315, 71, 16);
		panel.add(lblNewLabel_1_1_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1_2 = new JLabel("Edição");
		lblNewLabel_1_1_1_1_1_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1_2.setBounds(10, 349, 71, 16);
		panel.add(lblNewLabel_1_1_1_1_1_2);
		
		txtconteudo = new JTextField();
		txtconteudo.setBounds(112, 271, 150, 20);
		panel.add(txtconteudo);
		txtconteudo.setColumns(10);
		
		txtnumerop = new JTextField();
		txtnumerop.setBounds(112, 314, 150, 20);
		panel.add(txtnumerop);
		txtnumerop.setColumns(10);
		
		txtedicao = new JTextField();
		txtedicao.setBounds(112, 348, 150, 20);
		panel.add(txtedicao);
		txtedicao.setColumns(10);
		
		

		
		
		//carregarCategoria();
		

	}
	
	
	
	
	
	public class CategoriaItem {
		int id;
		String nome;
		
		
		public CategoriaItem(int id, String nome) {
			this.id = id;
			this.nome = nome;
		}
		
		@Override
		public String toString() {
			return nome;
		}
	}
	
	public class AutorItem {
		int id;
		String nome;
		
		
		public AutorItem(int id, String nome) {
			this.id = id;
			this.nome = nome;
		}
		
		@Override
		public String toString() {
			return nome;
		}
	}
	
	
	public class EditoraItem {
		int id;
		String nome;
		
		
		public EditoraItem(int id, String nome) {
			this.id = id;
			this.nome = nome;
		}
		
		@Override
		public String toString() {
			return nome;
		}
	}

	
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	private JTextField txtconteudo;
	private JTextField txtnumerop;
	private JTextField txtedicao;
	private JComboBox txtcategoria;
	private JComboBox txtautor;
	private JComboBox txteditora;
	
	
	

	public void Conectar() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/slivro", "root", "M@7h3u$");
		} catch (ClassNotFoundException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} catch(SQLException ex) {
			
		}
	}
	
	
	public void Categoria() {
		JComboBox txtcategoria = new JComboBox(); //Alternativa provisoria
		try {
			pst = con.prepareStatement("select * from categoria");
			rs = pst.executeQuery();
			txtcategoria.removeAllItems(); //De variavel local para campo
			
			while(rs.next()) {
				txtcategoria.addItem(new CategoriaItem(rs.getInt(1), rs.getString(2))); //toolbox sem opcao de String
			}
			
			
			//Solução GPT
			txtcategoria.revalidate(); // Atualiza a interface gráfica
			txtcategoria.repaint();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	
	public void carregarLivro() {
		int c;
		try {
			pst = con.prepareStatement("select l.id, l.lnome, c.catnome, a.nome, e.nome, l.conteudos, l.paginas, l.edicao from livro l join categoria c on l.categoria = c.id join autor a on l.autor = a.id join editora e on l.editora = e.id"); // Tabela so mostrara registros se mudar o nome da onde esta sendo chamado
			rs = pst.executeQuery();
			
			ResultSetMetaData rsd = rs.getMetaData();
			c = rsd.getColumnCount();
			
			
			
			
			/*DefaultTableModel d = (DefaultTableModel)jTable1.getModel();
			d.setRowCount(0);*/
			
			DefaultTableModel d = (DefaultTableModel) jTable1.getModel();
			d.setRowCount(0); // Limpa as linhas existentes
			jTable1.setModel(d); // Garante que o modelo está corretamente atribuído

			
			
			while(rs.next()) {
				Vector v2 = new Vector();
				
				for(int i = 1; i <= c; i++) {
					v2.add(rs.getString("l.id"));
					v2.add(rs.getString("l.lnome"));
					v2.add(rs.getString("c.catnome"));
					v2.add(rs.getString("a.nome"));
					v2.add(rs.getString("e.nome"));
					v2.add(rs.getString("l.conteudos"));
					v2.add(rs.getString("l.paginas"));
					v2.add(rs.getString("l.edicao"));
					
					
				}
				
				d.addRow(v2);
			}
		}catch(SQLException ex) {
			
		}
		
		
	}
	
	public void chamarAutor() {
		JComboBox txtautor = new JComboBox(); //Alternativa provisoria
		try {
			pst = con.prepareStatement("select * from autor");
			rs = pst.executeQuery();
			txtautor.removeAllItems(); //De variavel local para campo
			
			while(rs.next()) {
				txtautor.addItem(new AutorItem(rs.getInt(1), rs.getString(2))); //toolbox sem opcao de String
			}
			
			//Solução GPT
			txtautor.revalidate(); // Atualiza a interface gráfica
			txtautor.repaint();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	
	
	
	public void chamarEditora() {
		JComboBox txteditora = new JComboBox(); //Alternativa provisoria
		try {
			pst = con.prepareStatement("select * from editora");
			rs = pst.executeQuery();
			txteditora.removeAllItems(); //De variavel local para campo
			
			while(rs.next()) {
				txteditora.addItem(new EditoraItem(rs.getInt(1), rs.getString(2))); //toolbox sem opcao de String
			}
			
			//Solução GPT
			txteditora.revalidate(); // Atualiza a interface gráfica
			txteditora.repaint();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
}








