package sLivros;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Vector;

import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextPane;
import java.awt.TextArea;
import javax.swing.JSpinner;
import javax.swing.JList;
import javax.swing.SpinnerDateModel;
import java.util.Date;
import java.util.Calendar;
import com.toedter.calendar.JDayChooser;

import sLivros.Livro.CategoriaItem;

import com.toedter.calendar.JDateChooser;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;



public class EdLivro extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtid;
	private JTable jTable1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EdLivro frame = new EdLivro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	
	
	
	
	
	/**
	 * Create the frame.
	 */
	public EdLivro() {
		
		
		
		
		
		
		
		
		
		
		SwingUtilities.invokeLater(() -> carregarEdLivro());
		//Conexao DB
		Conectar();
		puxarLivro();
		carregarEdLivro();
		
		//===========================
		
		
												
								
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 490);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(10, 13, 864, 427);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Emissão Livro");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel.setBounds(55, 13, 194, 40);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ID Membro");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(10, 88, 81, 16);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Nome Membro");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(10, 137, 90, 16);
		panel.add(lblNewLabel_1_1);
		
		txtid = new JTextField();
		txtid.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				
				if(e.getKeyCode() == KeyEvent.VK_ENTER) {
					String mid = txtid.getText();
					
					try {
					pst = con.prepareStatement("select * from membro where id = ?");
					pst.setString(1, mid);
					rs = pst.executeQuery();
					
					String msg = "Id membro nãp encontrado";
					String tit = "Ops!";
					if(rs.next() == false) {
						
						JOptionPane.showMessageDialog(null, msg, tit, 2);
					}else {
						String nomemembro = rs.getString("nome");
						txtmembro.setText(nomemembro.trim());
					}
					}catch(SQLException ex) {
						
					}
				}
				
				
				
				
				
				
			}
		});
		txtid.setBounds(110, 86, 152, 22);
		panel.add(txtid);
		txtid.setColumns(10);
		
		JButton btnNewButton = new JButton("Adicionar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String mid = txtid.getText();
				BookItem bitem = (BookItem)txtlivro.getSelectedItem();
				
				SimpleDateFormat date_form = new SimpleDateFormat("YYYY-MM-dd");
				String emissaodata = date_form.format(txtedata.getDate());
				
				SimpleDateFormat date_form1 = new SimpleDateFormat("YYYY-MM-dd");
				String devolucaodata = date_form.format(txtrdata.getDate());
				
				
				
				String titl = "Sucesso!";
				String inf = "Livro emitido(a)!!";
				String info = "Ops!";
				String msg3 = "Algo errado";
				try {
					pst = con.prepareStatement("insert into emprestalivro(membroid, livroid, emissaodata, retornodata) values(?,?,?,?)");
					pst.setString(1, mid);
					pst.setInt(2, bitem.id);
					pst.setString(3, emissaodata);
					pst.setString(4, devolucaodata);
					
					
					int k = pst.executeUpdate();
					
					if(k == 1) {
						JOptionPane.showMessageDialog(null, inf, titl, 2);
						
						txtid.setText("");
						txtlivro.setSelectedIndex(-1);
						txtmembro.setText("");
						carregarEdLivro();
						//carregarLivro();
						
						
					}else {
						JOptionPane.showMessageDialog(null, msg3, info, 2);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton.setBounds(10, 319, 90, 40);
		panel.add(btnNewButton);
		
		JButton btnAtualizar = new JButton("Atualizar");
		btnAtualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				
				
				
				
			}
		});
		btnAtualizar.setBounds(112, 319, 90, 40);
		panel.add(btnAtualizar);
		
		JButton btnNewButton_1 = new JButton("Deletar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				
				
				
			}
		});
		btnNewButton_1.setBounds(10, 376, 90, 40);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Cancelar"); //Action aqui!!
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//alternativa provisoria
				 setVisible(false); 
				 
				 /*
				  * Por que essa alternativa funcionou? Nao sei. setVisible(false) excluiu a janela
				  * sem parar o programa.
				  */
				  
				

			}
		});
		btnNewButton_2.setBounds(112, 376, 90, 40);
		panel.add(btnNewButton_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
				
				btnNewButton.setEnabled(false);
				
			}
		});
		//AQUI!!! SCR
		scrollPane.setBounds(296, 13, 558, 413);
		panel.add(scrollPane);
		
		
		//DefaultTableModel tableModel = new DefaultTableModel(0,0); //Recem adicionado
		jTable1 = new JTable();
		scrollPane.setViewportView(jTable1);
		jTable1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Membro Nome", "Livro", "Data", "Data Retorno"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, Object.class, Object.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		jTable1.setShowVerticalLines(true);
		jTable1.setShowHorizontalLines(true);
		
	
		JLabel lblNewLabel_1_1_1 = new JLabel("Livro");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1.setBounds(10, 184, 71, 16);
		panel.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Data");
		lblNewLabel_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_1.setBounds(10, 229, 71, 16);
		panel.add(lblNewLabel_1_1_1_1);
		
		txtlivro = new JComboBox();
		txtlivro.setBounds(110, 182, 150, 22);
		panel.add(txtlivro);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Data Retorno");
		lblNewLabel_1_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1.setBounds(10, 272, 90, 16);
		panel.add(lblNewLabel_1_1_1_1_1);
		
		txtmembro = new JTextField();
		txtmembro.setBounds(110, 136, 152, 20);
		panel.add(txtmembro);
		txtmembro.setColumns(10);
		
		txtedata = new JDateChooser();
		txtedata.setBounds(110, 225, 108, 20);
		panel.add(txtedata);
		
		txtrdata = new JDateChooser();
		txtrdata.setBounds(110, 272, 108, 20);
		panel.add(txtrdata);
		
		

		
		
		//carregarCategoria();
		

	}
	
	
	
	
	
	

	
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	private JComboBox txtlivro;
	private JTextField txtmembro;
	private JDateChooser txtedata;
	private JDateChooser txtrdata;
	
	
	

	public void Conectar() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/slivro", "root", "M@7h3u$");
		} catch (ClassNotFoundException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} catch(SQLException ex) {
			
		}
	}
	
	
	public class BookItem{
		int id;
		String nome;
		
		public BookItem(int id, String nome) {
			this.id = id;
			this.nome = nome;
		}
		
		public String toString() {
			return nome;
		}
	}
	
	public void puxarLivro() {
			try {
				
				
				pst = con.prepareStatement("select * from livro");
				rs = pst.executeQuery();
				JComboBox txtlivro = new JComboBox(); //Provisorio
				txtlivro.removeAllItems(); //De variavel local para campo
				
				while(rs.next()) {
					txtlivro.addItem(new BookItem(rs.getInt(1), rs.getString(2))); //toolbox sem opcao de String
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		
	}
	
	
	
	
	public void carregarEdLivro() {
		int c;
		try {
			pst = con.prepareStatement("select e.id, m.nome, l.lnome, e.emissaodata, e.retornodata from emprestalivro e join membro m on e.membroid = m.id join livro l on e.livroid = l.id"); // Tabela so mostrara registros se mudar o nome da onde esta sendo chamado
			rs = pst.executeQuery();
			
			ResultSetMetaData rsd = rs.getMetaData();
			c = rsd.getColumnCount();
			
			
			
			
			/*DefaultTableModel d = (DefaultTableModel)jTable1.getModel();
			d.setRowCount(0);*/
			
			jTable1 = new JTable();//provisorio!!!!!!!!!!
			
			DefaultTableModel d = (DefaultTableModel) jTable1.getModel();
			d.setRowCount(0); // Limpa as linhas existentes
			jTable1.setModel(d); // Garante que o modelo está corretamente atribuído

			
			
			while(rs.next()) {
				Vector v2 = new Vector();
				
				for(int i = 1; i <= c; i++) {
					v2.add(rs.getString("l.id"));
					v2.add(rs.getString("m.nome"));
					v2.add(rs.getString("l.lnome"));
					v2.add(rs.getString("e.emissaodata"));
					v2.add(rs.getString("e.retornodata"));
					
					
					
				}
				
				d.addRow(v2);
			}
		}catch(SQLException ex) {
			
		}
		
		
	}
	
	
	
	
	
	
	
	
}








